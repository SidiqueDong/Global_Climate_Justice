# Reproducible Analysis Code

**Paper:** Global patterns of inequality in urban exposure to climate hazards  
**Journal:** *Nature Cities*  
**Authors:** Sidique Gawusu, Benjamin K. Sovacool, Xiaobing Zhang, Oisik Das, Seidu Abdulai Jamatutu, Abubakari Ahmed, Imelda Piri

---

## Contents

| File | Description |
|------|-------------|
| `reproducible_analysis.ipynb` | Jupyter notebook reproducing all analyses, figures, and tables |
| `analysis_script.py` | Standalone Python script (equivalent to notebook) |
| `README.md` | This file |

## Data

The analysis uses the **GHS Urban Centre Database 2025 (GHS-UCDB R2024A V1.1)** GeoPackage.

- **DOI:** [10.2905/1a338be6-7eaf-480c-9664-3a8ade88cbcd](https://doi.org/10.2905/1a338be6-7eaf-480c-9664-3a8ade88cbcd)
- **Download:** [JRC Data Catalogue](https://data.jrc.ec.europa.eu/dataset/1a338be6-7eaf-480c-9664-3a8ade88cbcd)
- **Licence:** European Commission Reuse and Copyright Notice
- **Size:** ~1.2 GB (GeoPackage)

Place the `.gpkg` file in the working directory or update `DATA_PATH` in Cell 3.

## Requirements

Python >= 3.9 with the following packages:

```
numpy
pandas
matplotlib
seaborn
scipy
statsmodels
geopandas
pyogrio
openpyxl
```

Install all dependencies:
```bash
pip install numpy pandas matplotlib seaborn scipy statsmodels geopandas pyogrio openpyxl
```

## Usage

### Jupyter Notebook (recommended)
```bash
jupyter notebook reproducible_analysis.ipynb
```

### Standalone script
```bash
python analysis_script.py
```

### Google Colab
Upload `reproducible_analysis.ipynb` to Google Colab, uncomment the drive mount lines in Cell 3, and update `DATA_PATH` to point to the GeoPackage in your Google Drive.

## Outputs

The analysis produces:

### Figures (`figures/`)
| File | Manuscript location |
|------|-------------------|
| `Figure1_multihazard_exposure.pdf` | Figure 1 |
| `Figure2_LECZ_vs_HDI.pdf` | Figure 2 |
| `Figure3_hazard_HDI_heatmap.pdf` | Figure 3 |
| `Figure4_demographics.pdf` | Figure 4 |
| `Figure5_quantile_regression.pdf` | Figure 5 |
| `ExtendedData_correlation_matrix.pdf` | Extended Data Figure 3 |

### Tables (`tables/`)
| File | Manuscript location |
|------|-------------------|
| `Table1_descriptive_stats.csv` | Table 1 |
| `regression_results.csv` | Extended Data Table 1 |
| `ExtendedData_regional.csv` | Extended Data |
| `ExtendedData_top50.csv` | Extended Data Table 3 |

All figures are saved in both PDF and PNG formats. All tables are saved in both CSV and XLSX formats.

## Generative AI Disclosure

Claude (Anthropic) was used to assist with writing the python script for the analysis, and manuscript editing. This is documented in the Methods section of the manuscript, in accordance with Nature Cities policy.

## Licence

Code is provided under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The GHS-UCDB dataset is subject to the European Commission Reuse and Copyright Notice.
